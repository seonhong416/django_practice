from django.shortcuts import render

def board(request) :
    # 게시글 리스트
    if request.method == 'GET' :
        context = {
            'title' : '안녕하세요'
        }
        
        
        return render(request, 'page/index.html', context = context)
    
    # request 객체의 메소드가 GET방식이면
    # request 객체의 index.html에 렌더링 해줘
